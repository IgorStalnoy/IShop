package com.example.ishop.exceptions;

public class CustomerAlreadyExistException extends Exception {

    public CustomerAlreadyExistException() {
    }

    public CustomerAlreadyExistException(Throwable cause) {
        super(cause);
    }

}
