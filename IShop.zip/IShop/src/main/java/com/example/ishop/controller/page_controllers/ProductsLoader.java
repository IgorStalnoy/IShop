package com.example.ishop.controller.page_controllers;

import com.example.ishop.model.Product.Computer;
import com.example.ishop.model.Product.Furniture;
import com.example.ishop.model.Product.HouseholdChemicals;
import com.example.ishop.model.Product.Product;
import com.example.ishop.model.ScreenNames;
import javafx.concurrent.Task;
import javafx.fxml.FXMLLoader;
import javafx.scene.paint.Color;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.example.ishop.model.ScreenNames.VENDOR_PAGE_SCREEN;
import static java.lang.Thread.sleep;

public class ProductsLoader extends Task<List<Product>> {

    File file;
    private final HashMap<ScreenNames, FXMLLoader> controllerMap;

    public ProductsLoader(File file, HashMap<ScreenNames, FXMLLoader> controllerMap) {
        this.file = file;
        this.controllerMap = controllerMap;
    }

    @Override
    protected List<Product> call() throws Exception {
        List<Product> productsList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                try {
                    if (Integer.parseInt(values[1]) == 1) {
                        System.out.println(Thread.currentThread().getName());
                        int categoryID = Integer.parseInt(values[1]);
                        int price = Integer.parseInt(values[2]);
                        int count = Integer.parseInt(values[3]);
                        String model = values[5];
                        String brand = values[4];
                        String type = values[6];
                        int processorSpeed = Integer.parseInt(values[7]);
                        int ramSize = Integer.parseInt(values[8]);
                        int hddSize = Integer.parseInt(values[9]);
                        Product product = new Computer(1, categoryID, price, count, model, brand, type, processorSpeed, ramSize, hddSize);
                        productsList.add(product);
                    } else if (Integer.parseInt(values[1]) == 2) {
                        int categoryID = Integer.parseInt(values[1]);
                        int price = Integer.parseInt(values[2]);
                        int count = Integer.parseInt(values[3]);
                        String model = values[4];
                        String material = values[5];
                        String color = values[6];
                        Product product = new Furniture(1, categoryID, price, count, model, material, color);
                        productsList.add(product);
                    } else if (Integer.parseInt(values[1]) == 3) {
                        int categoryID = Integer.parseInt(values[1]);
                        int price = Integer.parseInt(values[2]);
                        int count = Integer.parseInt(values[3]);
                        String model = values[4];
                        String brand = values[5];
                        String appointment = values[6];
                        String smell = values[7];
                        Product product = new HouseholdChemicals(1, categoryID, price, count, model, brand, appointment, smell);
                        productsList.add(product);
                    }
                } catch (RuntimeException e) {
                    VendorPageController vendorPageController = controllerMap.get(VENDOR_PAGE_SCREEN).getController();
                    vendorPageController.infoMessage.setTextFill(Color.RED);
                    vendorPageController.infoMessage.setText("Invalid data, please check your file");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return productsList;
    }
}
