package com.example.ishop.exceptions;

public class CustomerDoesNotExistException extends Exception {
    public CustomerDoesNotExistException() {
    }

}
