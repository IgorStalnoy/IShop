package com.example.ishop.exceptions;

public class InvalidCredentialsException extends Exception {
    public InvalidCredentialsException() {
    }

}
