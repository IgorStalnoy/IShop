package com.example.ishop.db;

public class DBConstants {

    public final static String DBNAME = "IShopDB.db";
    public final static String DBPATH = "jdbc:sqlite:src\\main\\java\\com\\example\\ishop\\db\\" + DBNAME;
}
